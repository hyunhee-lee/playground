=====
VNTG - Core
=====

Core is a Vntg-Django app to conduct Web-based VNTG Project. For each question,
visitors can choose between a fixed number of answers.

Detailed documentation is in the "docs" directory.

Quick start
-----------

1. Add "core" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        ...
        'core',
    ]

2. Include the core URLconf in your project urls.py like this::

    path('core/', include('core.urls')),

3. Run ``python manage.py migrate`` to create the common models.

4. Start the development server and visit http://127.0.0.1:8000/admin/
   to create a core (you'll need the Admin app enabled).

5. Visit http://127.0.0.1:8000/core/ to participate in the core.