from django.db.models import Q


def get_list(model, filter_data=None, columns: list = None, order_by: list = None):
    """모델을 통한 query를 실행하고, 지정한 컬럼의 조회 결과를 반환합니다.

    :param model: 모델
    :param filter_data: 모델 필터 조건
    :param columns: 조회하고자 하는 컬럼들
    :param order_by: 정정렬 조건 예: ['-sort_seq', 'etc_ctnt1']
    """
    columns = [] if columns is None else columns
    order_by = [] if order_by is None else order_by

    # db 조회 - filter 타입에 따라 적용방식이 다름
    if type(filter_data) is Q:
        # Q이면 그대로 filter에 적용
        db_rows = model.objects.filter(filter_data).values(*columns).order_by(*order_by)
    else:
        # Q가 아니면, kwargs로 적용
        db_rows = model.objects.filter(**filter_data).values(*columns).order_by(*order_by)

    if len(db_rows) == 0:
        return None

    return db_rows


def get_row(model, filter_data=None, columns: list = None):
    """지정한 모델로 필터를 적용하고 지정한 컬럼의 행을 반환합니다.

    :param model: 모델
    :param filter_data: 모델 필터 조건
    :param columns: 조회하고자 하는 컬럼들
    """
    # 목록 조회
    db_rows = get_list(model, filter_data, columns)
    if db_rows is None:
        return None

    return db_rows[0]


def get_value(model, filter_data=None, column: str = None):
    """지정한 모델로 필터를 적용하고 지정한 컬럼의 값을 반환합니다.

    :param model: 모델
    :param filter_data: 모델 필터 조건
    :param column: 조회하고자 하는 컬럼, 없으면 임의의 첫번째 컬럼 반환됨.
    """
    # 단일 값을 리스트로 변환
    columns = []
    if column is not None:
        columns.append(column)

    # 목록 조회
    db_row = get_row(model, filter_data, columns)

    if db_row is None:
        return None

    # 리스트로 변환
    row_list = list(db_row.values())
    return row_list[0]


def check_autofield_by_key_columns(model, key_columns: list) -> bool:
    for col_name in key_columns:
        if model._meta.get_field(col_name).get_internal_type() == 'AutoField':
            return True

    return False
