import unicodedata
from io import BytesIO
import pandas as pd
from openpyxl import Workbook
from rest_framework.renderers import BaseRenderer


def text_nomarlize(text: str) -> str:
    if text is not None and len(text) > 0 and '' in text:
        # return unicodedata.normalize('NFKD', text)
        return text.replace(u'\xa0', u' ')
    else:
        return text


def read_xl_file(xl_file, sheet_name, column_option: dict) -> list:
    """엑셀 파일을 읽어 데이터를 행 리스트로 반환합니다.

    엑셀 칼럼에 대한 정의를 아래와 같이 설정합니다. 칼럼 순서는 관계 없음.
    column_option = {'엑셀 칼럼명': {'column_name': '변경할 칼럼명', 'data_type': 엑셀칼럼 DataType}, 'converter': text_nomarize, ...}

    예시)
    column_option = {'사번': {'column_name': 'emp_no', 'data_type': str},
                     '검진일자': {'column_name': 'check_date', 'data_type': datetime},
                     '검진종류': {'column_name': 'check_type', 'data_type': str},
                     '검진항목': {'column_name': 'check_item_code', 'data_type': str},
                     '검진판정': {'column_name': 'dcsn_code', 'data_type': str},
                     '검진병원': {'column_name': 'check_hosp_code', 'data_type': str},
                     '업무수행': {'column_name': 'job_prfm_code', 'data_type': str},
                     '검사소견': {'column_name': 'check_desc', 'data_type': str, 'converter': text_nomarlize}
                     }

    :param xl_file: 읽고자하는 엑셀 파일(request.FILE)
    :param sheet_name: str(읽기 대상인 엑셀 시트 명), int, list 또는 None, Default 0 -
        시트 이름에는 문자열이 사용됩니다. 정수는 0으로 인덱싱된 시트 위치에 사용됩니다(차트 시트는 시트 위치로 계산되지 않음).
        문자열/정수 목록은 여러 시트를 요청하는 데 사용됩니다. 모든 워크시트를 가져오려면 없음을 지정합니다.
        사용 가능한 케이스:
        기본값 0: 첫 번째 시트를 DataFrame 으로
        1: DataFrame 으로 두 번째 시트
        "Sheet1": 이름이 "Sheet1"인 시트 로드
        [0, 1, "Sheet5"]: 첫 번째, 두 번째 및 "Sheet5"라는 시트를 DataFrame 의 dict로 로드합니다.
    :param column_option: 엑셀 칼럼 읽기 옵션(위 설명 참조)
    """
    column_renames = dict((k, v['column_name']) for k, v in column_option.items())
    column_types = dict((k, v['data_type']) for k, v in column_option.items())
    converters = dict((k, v['converter']) for k, v in column_option.items() if 'converter' in v.keys())

    # DataFrame으로 읽기
    raw_data = pd.read_excel(io=xl_file, sheet_name=sheet_name, dtype=column_types, converters=converters)

    # 칼럼 이름 normalize (nbsp -> ' '로 변환)
    normalized_column_names = dict((raw_data.columns[i], text_nomarlize(raw_data.columns[i]))
                                   for i in range(len(raw_data.columns)))
    raw_data.rename(columns=normalized_column_names, inplace=True)

    # 칼럼 이름 변경
    raw_data.rename(columns=column_renames, inplace=True)

    # DataFrame에서 불필요한 칼럼 제거(column_option에서 지정하지 않은 칼럼 제거)
    column_list = list(column_renames.values())
    for col in raw_data.columns:
        if col not in column_list:
            # axis=1 -> 칼럼
            raw_data.drop(col, axis=1, inplace=True)

    # Column/Row 목록 추출
    columns = raw_data.columns
    rows = raw_data.values.tolist()

    # Column + Row
    excel_data = [dict(zip([column for column in columns], row)) for row in rows]

    return excel_data


def write_xl_file(xl_data, sheet_name: str, column_options: dict):
    """데이터를 엑셀 파일에 기록하고 엑셀 파일을 반환합니다.

    엑셀 칼럼에 대한 정의를 아래와 같이 설정합니다.
    컬럼 나열 순서대로 엑셀에 기록됩니다.
    column_option = {'데이터 칼럼명': {'caption': '엑셀 캡션명', 'width': 10, 'align': 'center', 'format': ''}, ...}

    -> 데이터 칼럼명과 엑셀 캡션명은 필수 항목입니다.

    예시)
    column_options = {
        'busi_place_name': {'caption': '사업장', 'align': 'center'},
        'emp_no': {'caption': '사번', 'align': 'center'},
        'emp_name': {'caption': '성명', 'align': 'center'},
        'plant_code': {'caption': '부서/공장코드', 'width': 15, 'align': 'center'},
        'plant_name': {'caption': '부서/공장', 'width': 15, 'align': 'left'},
        'equip_name': {'caption': '설비', 'width': 10, 'align': 'left'},
        'unit_work_code': {'caption': '직무코드', 'width': 10, 'align': 'center'},
        'unit_work': {'caption': '직무', 'width': 15},
        'rg_date': {'caption': '등록일자', 'width': 15, 'align': 'center', 'format': 'yyyy-MM-dd'},
        'mgt_type_name': {'caption': '관리구분', 'align': 'center'},
    }

    :param xl_data: 엑셀 파일에 기록할 데이터
    :param sheet_name: 엑셀 시트 명
    :param column_options: 엑셀 칼럼 쓰기 옵션(위 설명 참조)
    """
    column_renames = dict((k, v['caption']) for k, v in column_options.items())

    # 캡션 변환(colum name -> caption)
    for col_name in column_renames.keys():
        for row in xl_data:
            row[column_renames[col_name]] = row.pop(col_name)

    # 엑셀 서식 적용하여 파일 생성합니다.
    df = pd.DataFrame(data=xl_data, columns=list(val for key, val in column_renames.items()))

    # 엑셀 파일을 생성하고, 데이터를 기록합니다.
    excel_file = BytesIO()
    with pd.ExcelWriter(excel_file, engine='xlsxwriter') as xlwriter:
        # 데이터를 엑셀에 기록
        df.to_excel(xlwriter,
                    sheet_name=sheet_name,
                    columns=list(val for key, val in column_renames.items()),
                    index=False)

        # 엑셀 컬럼 너비 설정
        column_widths = dict((v['caption'], v['width'])
                             for k, v in column_options.items() if 'width' in v.keys())
        if len(column_widths.keys()) > 0:
            workbook = xlwriter.sheets[sheet_name]
            for col_name in column_widths.keys():
                col_idx = df.columns.get_loc(col_name)
                workbook.set_column(col_idx, col_idx, column_widths[col_name])

        # 엑셀 칼럼 text align 설정
        column_aligns = dict((v['caption'], v['align'])
                             for k, v in column_options.items() if 'align' in v.keys())
        if len(column_widths.keys()) > 0:
            workbook = xlwriter.sheets[sheet_name]
            for col_name in column_widths.keys():
                col_idx = df.columns.get_loc(col_name)
                workbook.set_column(col_idx, col_idx, column_widths[col_name])

        # 엑셀 셀 포맷
        # https://xlsxwriter.readthedocs.io/example_pandas_column_formats.html

        xlwriter.save()

    return excel_file


class ExcelRenderer(BaseRenderer):
    """Excel Renderer
    """
    media_type = 'application/ms-excel'
    format = 'xlsx'
    level_sep = '.'

    def render(self, data, media_type=None, renderer_context=None):
        """Renders serialized *data* into Excel. For a dictionary:
        """
        if data is None:
            return False

        stream = BytesIO()
        wb = Workbook(write_only=True)
        ws = wb.create_sheet()

        if 'header' in data:
            headers = data['header']
            ws.append(headers)

        if 'rows' in data:
            for item in data['rows']:
                ws.append([item.get(key, None) for key in headers])

        wb.save(stream)
        value = stream.getvalue()
        stream.close()

        return value
