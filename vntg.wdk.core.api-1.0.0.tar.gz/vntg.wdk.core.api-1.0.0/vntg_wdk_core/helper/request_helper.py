from rest_framework_simplejwt.authentication import JWTAuthentication


def get_current_request():
    """현재 요청(Request)을 반환합니다."""
    from crum import get_current_request
    return get_current_request()


def get_current_user():
    """현재 요청(Request)에 대한 사용자(User)를 반환합니다."""
    from crum import get_current_user
    return get_current_user()


def get_current_token():
    """Request에 있는 jwt token을 추출하여 반환합니다."""
    jwt_object = JWTAuthentication()
    req = get_current_request()
    header = jwt_object.get_header(req)
    raw_token = jwt_object.get_raw_token(header)
    validated_token = jwt_object.get_validated_token(raw_token)
    return validated_token


def get_current_payload() -> dict:
    """Request에 있는 jwt token의 payload를 추출하여 반환합니다."""
    # jwt_object = JWTAuthentication()
    # req = get_current_request()
    # header = jwt_object.get_header(req)
    # raw_token = jwt_object.get_raw_token(header)
    # validated_token = jwt_object.get_validated_token(raw_token)
    validated_token = get_current_token()
    return validated_token.payload


def get_payload_value(payload_key: str) -> str:
    """jwt token payload에서 요청한 키에 해당하는 값을 반환합니다."""
    payload = get_current_payload()
    return payload[payload_key]


def get_current_user_id() -> str:
    """jwt token에 설정된 현재 사용자의 user_id를 반환합니다."""
    return get_payload_value('user_id')


def get_current_system_type() -> str:
    """jwt token에 설정된 현재 사용자의 system_type를 반환합니다."""
    return get_payload_value('system_type')


def get_corp_code_by_current_user() -> str:
    """jwt token에 설정된 현재 사용자의 법인코드를 반환합니다."""
    return get_payload_value('corp_code')


def get_busi_place_by_current_user() -> str:
    """jwt token에 설정된 현재 사용자의 사업장코드를 반환합니다."""
    return get_payload_value('busi_place')


def get_dept_code_by_current_user() -> str:
    """jwt token에 설정된 현재 사용자의 부서코드를 반환합니다."""
    return get_payload_value('dept_code')


def get_emp_no_by_current_user() -> str:
    """jwt token에 설정된 현재 사용자의 사원번호를 반환합니다."""
    return get_payload_value('emp_no')


