

# Dictionary, List 자료에 대한 헬퍼
def get_stat_rows(req_data, table_name: str, row_stat: str) -> list:
    """지정한 상태의 행을 검색하여 리스트로 반환합니다. 없을 경우 None을 반환합니다.

    :param req_data: 클라이언트에서 요청한 데이터
    :param table_name: 요청 데이터에서 검색할 테이블명
    :param row_stat: 요청 데이터(테이블)에서 검색할 행의 상태(unchanged, added, modified, deleted)
    :return: 검색한 결과 행을 리스트로 반환합니다.
    """
    if table_name not in req_data:
        return None

    result_data = list(filter(lambda x: x['row_stat'] == row_stat, req_data[table_name]))
    return result_data


def get_req_rows(req_data_rows: list, filter_data: dict):
    """행 리스트에서 조건에 맞는 행을 찾아 반환합니다.

    :param req_data_rows: 클라이언트에서 요청한 데이터 중 특정 테이블에 속한 행 리스트
    :param filter_data: 행을 검색하고자 하는 {key: value, key: value, } 데이터입니다.
    :return: 검색한 행을 반환합니다.
    """
    found_rows = [row for row in req_data_rows
                  if all(row[target_key] == target_value
                         for target_key, target_value in filter_data.items())]
    return found_rows


def get_req_row(req_data_rows: list, key_data: dict):
    """행 리스트에서 조건에 맞는 행을 찾아 반환합니다.

    :param req_data_rows: 클라이언트에서 요청한 데이터 중 특정 테이블에 속한 행 리스트
    :param key_data: 행을 검색하고자 하는 {key: value, key: value, } 데이터입니다.
    :return: 검색한 행을 반환합니다. 여러 행이 검색되면 첫번째 행을 반환합니다.
    """
    found_rows = get_req_rows(req_data_rows=req_data_rows, filter_data=key_data)

    if found_rows is not None and len(found_rows) > 0:
        return found_rows[0]
    return None
