import re


def convert_parameter(query: str) -> str:
    """파라미터 명 변환
    PostgreSQL 파라미터를 Python 파라미터로 변환합니다.

    Python named parameter - %(p_system_code)s 형태로 사용
    postgresql :p_system_code -> %(p_system_code)s 로 변경
    파라미터 명은 반드시 ':'로 시작해야 합니다.

    :param query: PostgreSQL 파라미터르르 사용하는 원시 쿼리
    :return: 변환된 파라미터가 적용된 쿼리
    """
    # 파라미터 정규식 검색 패턴
    pattern_string = ':p_[a-zA-Z0-9_]+'

    # 정규식으로 변환 대상 파라미터 찾기
    regex = re.compile(pattern_string)
    found = regex.findall(query)

    if len(found) == 0:
        return query

    # 정규식으로 찾은 파라미터를 중복제거하고, Python named parameter로 변환
    parameter_data = dict((parameter, parameter.replace(':', '')) for parameter in found)
    parameter_data = dict((key, f'%({value})s') for key, value in parameter_data.items())

    # query 내에 있는 파라미터 적용 - :p_parameter -> %(p_parameter)s
    for key, value in parameter_data.items():
        query = query.replace(key, value)

    return query
