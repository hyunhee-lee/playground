import os

import django.apps

from vntg_wdk_core.helper.query_helper import convert_parameter


def lock_file(file):
    import os
    # cross-platform 파일 잠금 기능이 필요함
    # https://code-examples.net/en/q/77985

    if os.name == 'posix':
        # Linux
        import fcntl

        fcntl.flock(file, fcntl.LOCK_EX | fcntl.LOCK_NB)
    elif os.name == 'nt':
        # Windows
        from msvcrt import locking, LK_RLCK
        from os.path import getsize, realpath

        file_size = getsize(realpath(file.name))
        locking(file.fileno(), LK_RLCK, file_size)
    else:
        raise Exception('운영체제를 확인할 수 없어 파일을 잠글 수 없습니다.')


def unlock_file(file):
    import os
    # cross-platform 파일 잠금 기능이 필요함
    # https://code-examples.net/en/q/77985

    if os.name == 'posix':
        # Linux
        import fcntl

        fcntl.flock(file, fcntl.LOCK_UN)
    elif os.name == 'nt':
        # Windows
        from msvcrt import locking, LK_UNLCK
        from os.path import getsize, realpath

        file_size = getsize(realpath(file.name))
        locking(file.fileno(), LK_UNLCK, file_size)
    else:
        raise Exception('운영체제를 확인할 수 없어 잠금 파일을 해제할 수 없습니다.')


class SqlFileHelper:
    """SQL 파일 헬퍼
    - API View 객체에서 사용할 SQL 파일을 읽고, 해당 쿼리를 반환합니다.
    - API View 마다 생성해서 사용해야 합니다.
    """

    def __init__(self, package_name: str):
        """생성자
        # instance: API View 객체의 생성자에서 self 전달
        :param package_name: 하위 클래스의 패키지 이름(__package__)
        """
        self.__app_path = ''
        if package_name.startswith('apps'):
            self.__app_path = django.apps.apps.get_app_config(package_name.split('.')[1]).path
        else:
            self.__app_path = django.apps.apps.get_app_config(package_name.split('.')[0]).path
        self.__query_path = os.path.join(self.__app_path, 'query')

    def __find_file(self, start_path: str, file_name: str) -> str:
        """요청한 폴더에 해당 파일이 있는지 검색
        하위 폴더를 Recursion 검색 합니다.
        :param start_path: 검색 시작 경로
        :param file_name: 검색할 파일명(경로 미포함)
        :return: 찾은 파일명(경로 포함), 없을 경우 None
        """
        if os.path.isfile(os.path.join(start_path, file_name)):
            return os.path.join(start_path, file_name)

        # 없으면, 하위 폴더 검색
        for dir_name in list(
                filter(os.path.isdir, (os.path.join(start_path, dir_name) for dir_name in os.listdir(start_path)))):
            found = self.__find_file(os.path.join(start_path, dir_name), file_name)
            if found is not None:
                return found

        return None

    def get_query(self, sql_file_name) -> str:
        """SqlFileHelper 객체를 생성한 클래스의 query 폴더에서 sql 파일 내용을 반환합니다.
        sql 에 있는 postgresql 파라미터는 python named parameter로 변환합니다.

        :param sql_file_name: 검색할 sql 파일명
        :return: sql 파일 내용
        """
        # query 파일 찾기 - 현재 view 클래스 파일의 패키지 루트에 query 폴더
        # Business 노드에 정의된 쿼리명으로 파일을 찾고, 파일(SQL) 내용을 반환한다.
        # query 파일명은 클래스명(+api명)
        file_name = self.__find_file(self.__query_path, f'{sql_file_name}.sql')

        if file_name is None:
            raise Exception('조회 쿼리를 찾을 수 없습니다.')

        # query 파일 읽기
        query = ''
        with open(file=file_name, mode='r', encoding='utf8') as query_file:
            query = convert_parameter(query_file.read())

        return query
