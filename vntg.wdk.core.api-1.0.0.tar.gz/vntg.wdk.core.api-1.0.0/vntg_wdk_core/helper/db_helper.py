from django.db import connection


def get_data(query: str, parameters: dict, add_row_stat: bool = False) -> list:
    """Select query를 실행하고, 조회 결과를 반환합니다.

    :param query: 조회 쿼리
    :param parameters: 쿼리에 사용할 파라미터 사전
    :param add_row_stat: 조회 결과에 row_stat(unchanged)를 추가할지 여부
    :return: 조회 결과 리스트
    """

    with connection.cursor() as cursor:
        # query 실행
        cursor.execute(query, parameters)
        # 칼럼 목록 추출
        columns = cursor.description
        # 조회 결과 추출
        rows = cursor.fetchall()
        # 칼럼 정보 + 조회 결과
        serialized_data = [dict(zip([column.name for column in columns], row)) for row in rows]

        # row_stat 추가
        if len(serialized_data) > 0 and add_row_stat:
            # 조회한 데이터에 row 기본 상태값('unchanged')을 설정한다.
            for row in serialized_data:
                row['row_stat'] = 'unchanged'

        return serialized_data


def execute_dml(cmd: str, parameters: dict):
    """Insert/Update/Delete query를 실행하고, 결과를 반환합니다."""
    with connection.cursor() as cursor:
        # query 실행
        cursor.execute(cmd, parameters)

    return True


def execute_procedure(sp_name: str, in_parameters: dict):
    """Stored Procedure를 실행하고, 결과를 반환합니다.

    :param sp_name: 실행할 Stored Procedure 이름
    :param in_parameters: SP 실행에 필요한 in parameter 사전
    :return: sp에 out parameter가 있을 경우, out parameter 결과 사전을 반환합니다.
    """

    with connection.cursor() as cursor:
        # query 실행
        cursor.callproc(sp_name, in_parameters)
        # out parameter 목록 추출
        out_parameter_names = cursor.description
        # 조회 결과 추출(sp의 out parameter 결과가 반환됨)
        result = cursor.fetchall()
        # out parameter 설정
        out_parameters = [dict(zip([param.name for param in out_parameter_names], row)) for row in result]

        return out_parameters
