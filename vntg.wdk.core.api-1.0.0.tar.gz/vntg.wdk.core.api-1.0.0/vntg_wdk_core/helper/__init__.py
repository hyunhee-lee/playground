from pathlib import PurePath
from urllib.parse import urlparse


def get_node_name_by_path(request_path: str) -> str:
    """API endpoint(url) 마지막 부분을 이용하여 노드명을 검색합니다.
    ex) /api/vntg_wdk_common/COMM030E01/master 이면 COMM030E01를 찾습니다.
        /api/vntg_wdk_common/COMM030E01/master/ 이면 master를 찾습니다.

    :return: 해당 이름에 맞는 비즈니스 노드명
    """
    path_info = PurePath(urlparse(request_path).path)
    if request_path.endswith('/'):
        return path_info.parts[-1]
    else:
        return path_info.parts[-2]


def check_request_parameter(sql_param: list, req_param: list) -> bool:
    """두 개의 파라미터를 비교한 결과를 반환합니다.
    sql_param에 있는 목록이 req_param에 모두 있는 경우 True, 그렇지 않을 경우 False입니다.
    """
    result = set(sql_param) - set(req_param)
    return len(result) == 0


def is_empty_str(value: str) -> bool:
    """문자열이 null 또는 빈 문자열이면 True, 그렇지 않을 경우 False입니다."""
    return not (value and value.strip())


def is_not_empty_str(value: str) -> bool:
    """문자열이 있으면 True, null 또는 빈 문자열이면 False입니다."""
    return bool(value and value.strip())


def get_item_count(value) -> int:
    """파라미터의 요수 수를 반환합니다.

    - string: 문자 갯수
    - list: 요소 갯수
    - dict: 키 갯수
    """
    if value is None:
        return 0
    else:
        return len(value)


def is_null(value, rep_value):
    """value 값이 None(Null)이면, rep_value를 반환합니다. None(Null)이 아니면 value를 반환합니다.
    """
    if value is None:
        return rep_value
    else:
        return value


def is_null_or_empty(value, rep_value):
    """value 값이 None(Null) 또는 빈 문자열, 공백 문자열, 빈 요소(array, list, dict)이면, rep_value를 반환합니다.
     비어있지 않으면 value를 반환합니다.
    """
    if value is None:
        return rep_value
    else:
        if type(value) is str:
            # 문자열이면 None, 공백 문자열, 길이확인
            if is_empty_str(value):
                return rep_value
            else:
                return value
        else:
            if get_item_count(value) == 0:
                return rep_value
            else:
                return value
