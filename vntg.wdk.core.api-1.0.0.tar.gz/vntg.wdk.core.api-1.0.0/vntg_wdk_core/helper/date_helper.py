from datetime import datetime, date
from calendar import monthrange
from time import strftime

from dateutil.parser import parse as date_parse
from dateutil.relativedelta import relativedelta


def get_current_date() -> date:
    return datetime.now().date()


def get_current_datetime() -> datetime:
    return datetime.now()


def date_to_str_format(date_value: datetime, str_format: str) -> str:
    """날짜 형식을 지정한 포맷 형식의 문자열로 변환합니다."""
    return date_value.strftime(str_format)

  
def date_to_ymd(date_value: datetime) -> str:
    """날짜 형식을 년월일 형식의 문자열로 변환합니다."""
    return date_value.strftime('%Y%m%d')


def date_to_ym(date_value: datetime) -> str:
    """날짜 형식을 년월 형식의 문자열로 변환합니다."""
    return date_value.strftime('%Y%m')


def date_to_year(date_value: datetime) -> str:
    """날짜 형식을 년도 형식의 문자열로 변환합니다."""
    return date_value.strftime('%Y')


def string_to_date(date_string: str) -> datetime:
    """날짜 형식의 문자열을 날짜 형식으로 변환합니다.

    날짜 형식 (시간 포함)
    - yyyyMMddHHmmss
    - yyyy-MM-dd HH:mm:ss
    """
    try:
        return date_parse(date_string)
    except (ValueError, TypeError):
        raise ValueError(f'날짜 형식으로 변환할 수 없습니다. - {date_string}')


def string_to_ym(date_string: str) -> str:
    """날짜 형식의 문자열을 년월(yyyyMM) 형식의 문자열로 변환합니다."""
    date_value = string_to_date(date_string)
    return date_to_ym(date_value)


def string_to_year(date_string: str) -> str:
    """날짜 형식의 문자열을 년도(yyyy) 형식의 문자열로 변환합니다."""
    date_value = string_to_date(date_string)
    return date_to_year(date_value)


def add_months(date_value: datetime, month: int) -> datetime:
    """지정한 날짜에 달을 더하거나 뺀 후 반환합니다."""
    return date_value + relativedelta(months=month)


def get_first_day(date_value: datetime) -> datetime:
    """지정한 날짜가 속한 달의 첫번째 날짜를 반환합니다."""
    return date_value.replace(day=1)


def get_last_day(date_value: datetime) -> datetime:
    """지정한 날짜가 속한 달의 마지막 날짜를 반환합니다."""
    return datetime.replace(day=monthrange(date_value.year, date_value.month))


def trunc_datetime(date_value: datetime) -> datetime:
    """날짜 형식이 갖고 있는 시간을 제거합니다."""
    return date_value.replace(hour=0, minute=0, second=0, microsecond=0)


def compare_date(date1, date2) -> bool:
    """두 날짜가 같은지 비교합니다.
    일 기준이며, 둘다 None이면 True, 어느 하나가 None이면 False를 반환합니다.
    """
    if date1 is None and date2 is None:
        return True
    if date1 is None and date2 is not None:
        return False
    if date1 is not None and date2 is None:
        return False

    if type(date1) is datetime:
        date_value1 = date1
    else:
        date_value1 = string_to_date(date1)

    if type(date2) is datetime:
        date_value2 = date2
    else:
        date_value2 = string_to_date(date2)

    date_diff = date_value2.replace(tzinfo=None) - date_value1.replace(tzinfo=None)

    return date_diff.days == 0
