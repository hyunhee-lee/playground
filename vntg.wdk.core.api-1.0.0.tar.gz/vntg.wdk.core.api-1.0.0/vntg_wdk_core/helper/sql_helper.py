from vntg_wdk_core.helper.db_helper import get_data


def get_list(sql_query: str, filter_data: dict = None, columns: list = None):
    """query를 실행하고, 지정한 컬럼의 조회 결과를 반환합니다.

    :param sql_query: select 쿼리
    :param filter_data: 쿼리에 사용할 파라미터 사전
    :param columns: 조회 결과로 반환하고자 하는 컬럼들
    """
    # 결과 리스트
    serialized_data = []

    # 조회 query 실행
    db_rows = get_data(query=sql_query, parameters=filter_data)

    if len(db_rows) == 0:
        return None
    else:
        if columns is None:
            for db_row in db_rows:
                serialized_data.append({key: value for key, value in db_row.items()})
        else:
            for db_row in db_rows:
                serialized_data.append({key: value for key, value in db_row.items() if key in columns})

    return serialized_data


def get_row(sql_query: str, filter_data: dict = None, columns: list = None):
    """query를 실행하고, 지정한 컬럼의 조회 결과를 반환합니다.

    :param sql_query: select 쿼리
    :param filter_data: 쿼리에 사용할 파라미터 사전
    :param columns: 조회 결과로 반환하고자 하는 컬럼들
    """
    # 조회 query 실행
    result_row = {}
    db_rows = get_list(sql_query=sql_query, filter_data=filter_data, columns=columns)

    if db_rows is None:
        return None
    else:
        # 지정한 필드가 있는지 확인
        if columns is None:
            result_row = {key: value for key, value in db_rows[0].items()}
        else:
            result_row = {key: value for key, value in db_rows[0].items() if key in columns}

    return result_row


def get_value(sql_query: str, filter_data: dict = None, column: str = None):
    """query를 실행하고, 지정한 컬럼의 조회 결과를 반환합니다.

    :param sql_query: select 쿼리
    :param filter_data: 쿼리에 사용할 파라미터 사전
    :param column: 조회 결과로 반환하고자 하는 컬럼
    """
    # 결과 값
    result_value = None

    # 조회 query 실행
    db_row = get_row(sql_query=sql_query, filter_data=filter_data, columns=[column])

    if db_row is None:
        return None

    # 지정한 필드가 있는지 확인 - 없으면 첫번째 열 값 반환
    if column is None:
        result_value = [value for key, value in db_row.items()][0]
    else:
        result_value = db_row[column]

    return result_value
