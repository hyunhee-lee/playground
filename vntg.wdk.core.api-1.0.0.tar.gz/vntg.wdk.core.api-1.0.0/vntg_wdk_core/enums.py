from enum import Enum


class UpdateType(Enum):
    """데이터 저장 유형"""
    Insert = 1
    Update = 2
    Delete = 3
