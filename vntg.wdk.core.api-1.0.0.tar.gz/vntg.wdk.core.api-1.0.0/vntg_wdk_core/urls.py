from django.urls import path
from rest_framework_simplejwt.views import TokenRefreshView

from vntg_wdk_core.views.authview import MyObtainTokenPairView

urlpatterns = [
    # 사용자 정보 설정을 위해 vntg_wdk_core -> common으로 이동
    # path('login', MyObtainTokenPairView.as_view(), name='token_obtain_pair'),
    # path('login/refresh', TokenRefreshView.as_view(), name='token_refresh'),
]
