import logging

from rest_framework.permissions import AllowAny
from rest_framework_simplejwt.views import TokenObtainPairView

from vntg_wdk_core.serializers import MyTokenObtainPairSerializer

LOGGER = logging.getLogger(__name__)


# JWT Payload 를 커스터마이징하기 위한 View
class MyObtainTokenPairView(TokenObtainPairView):
    permission_classes = (AllowAny,)
    serializer_class = MyTokenObtainPairSerializer
