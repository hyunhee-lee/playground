import logging
import re
import traceback
from abc import ABCMeta, abstractmethod
from datetime import datetime

from django.db import transaction
from django.db.models import Q
from django.http import HttpResponse
from rest_framework import viewsets, status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from vntg_wdk_core.business import BusinessNode
from vntg_wdk_core.enums import UpdateType
from vntg_wdk_core.helper import db_helper, get_node_name_by_path, check_request_parameter
from vntg_wdk_core.helper.data_helper import get_req_row
from vntg_wdk_core.helper.file_helper import SqlFileHelper
from vntg_wdk_core.helper.model_helper import check_autofield_by_key_columns

LOGGER = logging.getLogger(__name__)


def create_response(success: bool,
                    code: int,
                    message: str,
                    data=None,
                    return_data=None,
                    return_status: status = None) -> Response:
    """"""
    if return_data is None:
        return_data = {'success': success, 'code': code, 'message': message, 'data': data}

    if return_status is None:
        if success:
            return_status = status.HTTP_200_OK
        else:
            return_status = status.HTTP_400_BAD_REQUEST

    return Response(return_data, return_status)


# 기본 API View
class BaseApiView(viewsets.ViewSet, metaclass=ABCMeta):
    """API View의 공통 기능을 반영하기 위한 베이스 클래스
    - 노드 정의를 통해 조회 및 저장을 실행하는 View 기초 클래스입니다.
    - 이 클래스를 상속받아 API View를 작성할 수 있지만, BaseModelApiView 또는 BaseSqlApiView 클래스를 상속받아 작성하세요.
    """
    permission_classes = (IsAuthenticated,)

    def __init__(self):
        """생성자"""
        # 부모 생성자 호출
        super().__init__()
        # 사용자 정보(request.user)
        self.user_id = ''
        # 노드 보관할 리스트 생성
        self.nodes = []
        # 노드 정의 메서드 호출
        self.define_nodes()

    # region 하위 클래스에서 구현할 메서드

    @abstractmethod
    def define_nodes(self):
        """하위 클래스에서 구현합니다.
        조회/저장할 각 노드를 생성하고 등록합니다.
        """
        raise NotImplementedError

    # endregion

    # region 노드 관리

    def _find_node_by_path(self, request_path: str) -> BusinessNode:
        """API endpoint(url) 마지막 부분을 이용하여 노드를 검색합니다.
        ex) /api/vntg_wdk_common/COMM030E01/master 이면 COMM030E01를 찾습니다.
            /api/vntg_wdk_common/COMM030E01/master/ 이면 master를 찾습니다.

        :return: 해당 이름에 맞는 비즈니스 노드
        """
        LOGGER.debug(f'{type(self).__name__} _find_node_by_path - path: {request_path}')
        if self.nodes is None or len(self.nodes) == 0:
            raise None

        return self._find_node(get_node_name_by_path(request_path))

    def _find_node(self, nodes: list, node_name: str) -> BusinessNode:
        """노드 리스트에서 지정한 이름을 갖는 노드를 찾아 반환합니다.

        :param nodes: 검색할 노드 리스트
        :param node_name: 검색할 노드 명
        :return: 검색된 비즈니스 노드
        """
        LOGGER.debug(f'{type(self).__name__} _find_node - node name: {node_name}')
        # 찾고자 하는 노드
        found_node = None
        for node in nodes:
            if node.node_name == node_name:
                found_node = node
                break
            if len(node.nodes) > 0:
                found_node = self._find_node(node.nodes, node_name)
                if found_node is not None:
                    break
        return found_node

    def _append_node(self, node: BusinessNode, child_node: BusinessNode = None) -> None:
        """지정한 노드에 자식 노드를 추가합니다.

        :param node: 부모 노드
        :param child_node: 자식 노드
        """
        if child_node is None:
            LOGGER.debug(f'{type(self).__name__} _append_node - node name: {node.node_name}')
            self.nodes.append(node)
        else:
            LOGGER.debug(
                f'{type(self).__name__} _append_node - node name: {node.node_name}, child node name: {child_node.node_name}')
            node.nodes.append(child_node)

    # endregion

    # region Row 검색

    def _get_row_by_key(self, model, pk_data: dict = None):
        """해당 모델에서 pk에 해당하는 Row를 반환합니다.
        pk_data {key: value} 파라미터를 사용하여 행을 검색하고 반환합니다.
        해당 조건으로 여러 행이 반환되면 예외로 간주합니다.
        baseview.py 패키지에서 사용합니다.

        :param model: 행을 검색할 모델입니다.
        :param key_data: 행을 검색하고자 하는 {key: value, key: value, } 데이터입니다.
        :return: 검색된 행을 반환합니다. 여러 행이 반환되면 오류를 발생시킵니다.
        """
        LOGGER.debug(f'{type(self).__name__} _get_row_by_key - mode name: {model.__name__}, pk_data: {str(pk_data)}')
        if pk_data is None and len(pk_data) == 0:
            return Exception('PK 정보가 누락되었습니다.')

        # PK 정보에 해당하는 자료 조회
        found = model.objects.filter(**pk_data)
        if len(found) > 1:
            return Exception('요청한 PK로 여러 행이 반환되었습니다.')

        # queryset.get => 반환 개수
        # 0개 : 모델클래스명.DoesNotExist 예외 발생, 1개 : 정상처리, 2개 : 모델클래스명.MultipleObjectsReturned 예외 발생
        try:
            return found.get()
        except Exception as ex:
            LOGGER.exception(ex)
            return None

    def _get_object(self, model, pk_data: dict = None):
        """해당 모델에서 pk에 해당하는 Row를 반환합니다.
        pk_data {key: value} 파라미터를 사용하여 행을 검색하고 반환합니다.
        해당 조건으로 여러 행이 반환되면 예외로 간주합니다.

        :param model: 행을 검색할 모델입니다.
        :param key_data: 행을 검색하고자 하는 {key: value, key: value, } 데이터입니다.
        :return: 검색된 행을 반환합니다. 여러 행이 반환되면 오류를 발생시킵니다.
        """
        LOGGER.debug(f'{type(self).__name__} _get_object - mode name: {model.__name__}, pk_data: {str(pk_data)}')
        if pk_data is None and len(pk_data) == 0:
            return Exception('PK 정보가 누락되었습니다.')

        # pk 파라미터 우선
        if len(pk_data) == 1:
            # pk_data가 dict 타입이라 list로 변환하여 첫번째 항목 추출
            pk = pk_data[list(pk_data.keys())[0]]
            try:
                return model.objects.get(pk=pk)
            except Exception as ex:
                LOGGER.exception(ex)
                return None
        else:
            found = model.objects.filter(**pk_data)
            if found is not None and len(found) == 1:
                return found[0]
        return None

    # endregion

    # region 조회

    def _remove_parameter_prefix(self, parameter_data: dict, exclude_all_value=True) -> dict:
        """파라미터 이름에 붙어 있는 p_ 접두사를 제거합니다.

        :param parameter_data: 접두사를 제거할 파라미터 데이터(dict) 입니다.
        :param exclude_all_value: 파라미터 값 중 '%'를 제외할지 여부입니다.
        :return: 접두사가 제거된 파라미터 데이터를 반환합니다.
        """
        if exclude_all_value:
            converted_data = dict((key[2:] if key.startswith('p_') else key, value)
                                  for key, value in parameter_data.items() if not value == '%')
        else:
            converted_data = dict((key[2:] if key.startswith('p_') else key, value)
                                  for key, value in parameter_data.items())
        return converted_data

    def _add_parameter_prefix(self, parameter_data: dict) -> dict:
        """파라미터 이름에 p_ 접두사를 추가합니다.
        이미 해당 접두사가 있는 경우는 추가하지 않습니다.

        :param parameter_data: 접두사를 추가할 파라미터 데이터(dict) 입니다.
        :return: 접두사가 적용된 파라미터 데이터를 반환합니다.
        """
        parameter_list = dict(
            (key if key.startswith('p_') else f'p_{key}', value) for key, value in parameter_data.items())
        return parameter_list

    @abstractmethod
    def _create_filter(self, node: BusinessNode, parameter_list=None, request_data=None, include_all=False):
        """조회 조건(필터) 생성 및 반환"""
        raise NotImplementedError

    @abstractmethod
    def _set_query(self, node: BusinessNode, request_data: dict):
        """해당 node에서 실행할 쿼리 설정
        - Model 기반: QuerySet 설정
        - Sql 기반: SQL 설정
        """
        raise NotImplementedError

    @abstractmethod
    def _get_list(self, node: BusinessNode):
        """쿼리(셋) 실행 및 결과 반환"""
        raise NotImplementedError

    def get_list_by_node_name(self, node_name: str, parameters: dict) -> list:
        """지정한 노드명의 데이터를 조회하여 리스트로 반환합니다.
        외부에서 사용할 수 있는 public 메서드입니다.

        :param node_name: 조회 실행할 노드명
        :param parameters: 조회 파라미터
        :return: 조건에 맞는 검색 결과 리스트
        """
        # 지정한 노드 명으로 검색
        node = self._find_node(nodes=self.nodes, node_name=node_name)

        if node is None:
            raise Exception('조회할 정보를 찾을 수 없습니다.')

        request_data = {}
        # 파라미터 접두사 설정
        if len(node.sql_filename) > 0:
            # SQL 기반 조회 - 접두사 설정
            request_data = self._add_parameter_prefix(parameters)
        else:
            # 모델 기반 조회 - 접두사 제거, '%' 제거
            request_data = self._remove_parameter_prefix(parameters)

        # QuerySet 설정(+조회조건 설정)
        self._set_query(node, request_data)

        # 조회
        serialized_data = self._get_list(node)

        return serialized_data

    def _exec_get_aggregate(self, node_info_list: list, request) -> Response:
        """조회 API를 실행합니다.
        여러 노드를 조회하여 하나의 자료로 반환합니다.

        node_info_list는 다음과 같이 작성합니다.
        [{'node_name': '조회할 노드 명', 'return_name': '조회결과 반환 이름'}, ...]

        예시) list, sublist 노드 조회를 요청한 경우
        요청: [{'node_name': 'list', 'return_name': 'code_master'},
               {'node_name': 'sublist', 'return_name': 'code_detail'}]
        반환: {'code_master': [list 노드 행 리스트], 'code_detail': [sublist 노드 행 리스트]}

        가급적 이 메서드는 재정의하지 마십시오.

        :param node_info_list: 조회할 노드 이름과 반환 이름 목록
        :param request: 요청 객체
        :return: 조회 결과 응답
        """
        # 조회시 반환할 데이터
        return_data = {'success': True, 'code': 1, 'message': 'OK', 'data': None}

        LOGGER.debug(f'{type(self).__name__} _exec_get_aggregate - path: {request.path}')

        # 조회시 반환할 데이터
        return_data = {'success': True, 'code': 1, 'message': 'OK', 'data': None}

        try:
            # 사용자 정보 설정
            self.user_id = request.user.user_id

            serialized_data = {}

            with transaction.atomic():
                # >> Begin transaction
                # 조회
                for node_info in node_info_list:
                    # 조회
                    node_data = self.get_list_by_node_name(node_name=node_info['node_name'], parameters=request.data)

                    LOGGER.debug(f'{type(self).__name__} _get - result: {len(node_data)}건 조회.')

                    # node의 테이블명으로 반환값 설정
                    serialized_data[node_info['return_name']] = node_data
                # >> End transaction

            # 반환 데이터 설정
            return_data['data'] = serialized_data

            # Django가 아닌, DRF의 Response를 사용해야 함
            return Response(return_data, status.HTTP_200_OK)
        except Exception as ex:
            LOGGER.exception(ex)
            return_data['success'] = False
            return_data['code'] = -1
            return_data['message'] = '예외 발생'
            # TODO: return_data['data'] = traceback.format_exc()
            return_data['data'] = str(ex)
            return Response(return_data, status.HTTP_400_BAD_REQUEST)

    def _exec_get(self, request, node_name=None) -> Response:
        """조회 API를 실행합니다.
        BaseViewSet을 상속받은 하위 클래스에서 이 메서드를 호출합니다.
        실행 결과를 포함하여 리턴합니다.

        가급적 이 메서드는 재정의하지 마십시오.

        :param request: 요청 객체
        :param node_name: 특정 노드를 조회할 경우 노드명을 지정합니다. 생략하면 endpoint를 이용하여 노드를 찾습니다.
        :return: 조회 결과 응답
        """
        LOGGER.debug(f'{type(self).__name__} _exec_get - path: {request.path}')

        # 조회시 반환할 데이터
        return_data = {'success': True, 'code': 1, 'message': 'OK', 'data': None}

        try:
            # 사용자 정보 설정
            self.user_id = request.user.user_id

            # 노드 검색
            if node_name is None:
                # request path를 이용하여 노드 검색
                node_name = get_node_name_by_path(request.path)

            with transaction.atomic():
                # >> Begin transaction
                # 조회
                serialized_data = self.get_list_by_node_name(node_name=node_name, parameters=request.data)
                # >> End transaction

            if len(serialized_data) == 0:
                msg = '조건에 맞는 자료가 없습니다.'
                LOGGER.info(f'{type(self).__name__} _get - message: {msg}')
                return_data['success'] = True
                return_data['code'] = 0
                return_data['message'] = msg
                return Response(return_data, status.HTTP_200_OK)
            else:
                LOGGER.info(f'{type(self).__name__} _get - result: {len(serialized_data)}건 조회.')
                return_data['data'] = serialized_data
                # Django가 아닌, DRF의 Response를 사용해야 함
                return Response(return_data, status.HTTP_200_OK)
        except Exception as ex:
            LOGGER.exception(ex)
            return_data['success'] = False
            return_data['code'] = -1
            return_data['message'] = '예외 발생'
            # TODO: return_data['data'] = traceback.format_exc()
            return_data['data'] = str(ex)
            return Response(return_data, status.HTTP_400_BAD_REQUEST)

    # endregion

    # region

    # endregion

    # region 저장

    def _perform_insert(self, node: BusinessNode, req_data) -> None:
        """클라이언트에서 요청한 데이터 중에서 node정보를 이용하여 신규 행을 찾아 Insert를 실행합니다.

        :param node: Insert를 실행할 노드
        :param req_data: 클라이언트에서 저장 요청한 데이터
        """
        # Insert 대상 요청 데이터
        if node.added_rows is None or len(node.added_rows) == 0:
            return

        LOGGER.debug(f'{type(self).__name__} _perform_insert - node name: {node.node_name}')

        # Serializer를 통해 저장, Model을 사용해도 됨
        # Serializer를 통하거나 Model.save()를 사용할때, 복합키를 갖고 있으면 저장 안됨(원래 있던 행이 업데이트 됨)

        # Serializer를 통해 저장
        # serialized = node.serializers(data=target_rows, many=isinstance(target_rows, list))
        # if serialized.is_valid(raise_exception=True):
        #     serialized.save()

        # Pre-Update 호출
        self._pre_update(node=node,
                         update_type=UpdateType.Insert,
                         update_data=node.added_target_rows,
                         req_data=req_data)

        # key 칼럼이 autofield일 경우, 값을 넣으면 중복 오류 발생할 수 있음. 저장시 autofield제외하고
        # - 저장된 값으로 target_row 값 재설정
        is_autofield = check_autofield_by_key_columns(model=node.model, key_columns=node.key_columns)

        # Model을 통해 저장(create() 사용) -> 복합키를 갖고 있으면 model.create() 사용 필요.
        for row in node.added_target_rows:
            # Insert 실행
            # dict 타입 변수에 **을 붙이면 키워드 인수로 전달됨 ($old_칼럼이 있으므로 node의 저장할 칼럼만 추출)
            if is_autofield:
                # autofield 있음 -> 저장할 행에서 autofield 칼럼 제외
                work_row = row.copy()
                for col_name in node.key_columns:
                    work_row.pop(col_name)
                # key 칼럼 없이 저장
                db_row = node.model.objects.create(**work_row)
                # 저장후 저장된 행의 autofield 값(key)을 targetrow와 요청 데이터에 설정
                new_key_data = dict((col_name, getattr(db_row, col_name))
                                    for col_name in node.update_columns if col_name in node.key_columns)
                node.change_key_values(target_row=row, new_key_data=new_key_data)
            else:
                # autofield 없음 -> 기존처럼 저장
                db_row = node.model.objects.create(**row)

            # node에 설정된 칼럼만 저장할 경우($old_칼럼이 있는 경우 사용)
            # db_row = node.model.objects.create(**{key: value for key, value in row.items()
            #                                       if key in node.update_columns})

            # query 로그 삭제 -> 개선 필요

            # DB 저장 내용을 요청 데이터에 설정
            self._set_update_result(req_data=req_data, node=node, db_row=db_row)

        # Post-Update 호출
        self._post_update(node=node,
                          update_type=UpdateType.Insert,
                          update_data=node.added_target_rows,
                          req_data=req_data)

    def _perform_update(self, node: BusinessNode, req_data) -> None:
        """클라이언트에서 요청한 데이터 중에서 node정보를 이용하여 수정 행을 찾아 Update를 실행합니다.

        :param node: Update를 실행할 노드
        :param req_data: 클라이언트에서 저장 요청한 데이터
        """
        # Update 대상 요청 데이터
        if node.modified_rows is None or len(node.modified_rows) == 0:
            return

        LOGGER.debug(f'{type(self).__name__} _perform_update - node name: {node.node_name}')

        # 모델을 시용하여 저장, 요청 메서드가 POST여서 그런지 serializers.is_valid()에서 오류 발생함
        # Serializer를 통해 저장, Model을 사용해도 됨

        # serialized = node.serializers(instance=db_row, data=row)
        # if serialized.is_valid(raise_exception=False):
        #     serialized.save()

        # Pre-Update 호출
        self._pre_update(node=node,
                         update_type=UpdateType.Update,
                         update_data=node.modified_target_rows,
                         req_data=req_data)

        # Model을 통해 저장(update() 사용) -> 복합키를 갖고 있으면 model.objects.filter().update() 사용 필요.
        for row in node.modified_target_rows:
            # 키 데이터 생성
            key_data = {key: value for key, value in row.items() if key in node.key_columns}

            # Update 실행
            affected_count = node.model.objects.filter(**key_data).update(**row)
            if affected_count == 0:
                raise Exception('요청한 행을 찾을 수 없어 업데이트 할 수 없습니다.')

            # query 로그 삭제 -> 개선 필요

            # DB 저장 내용을 요청 데이터에 설정
            db_row = self._get_row_by_key(model=node.model, pk_data=key_data)
            self._set_update_result(req_data=req_data, node=node, db_row=db_row)

        # Post-Update 호출
        self._post_update(node=node,
                          update_type=UpdateType.Update,
                          update_data=node.modified_target_rows,
                          req_data=req_data)

    def _perform_delete(self, node: BusinessNode, req_data) -> None:
        """클라이언트에서 요청한 데이터 중에서 node정보를 이용하여 삭제 행을 찾아 Delete를 실행합니다.
        저장 요청 데이터 중 삭제된 행은 마지막 set_row_stat_to_unchanged()에서 제거됩니다.

        :param node: Delete를 실행할 노드
        :param req_data: 클라이언트에서 저장 요청한 데이터
        """
        if node.deleted_rows is None or len(node.deleted_rows) == 0:
            return

        LOGGER.debug(f'{type(self).__name__} _perform_delete - node name: {node.node_name}')

        # Pre-Update 호출
        self._pre_update(node=node,
                         update_type=UpdateType.Delete,
                         update_data=node.deleted_target_rows,
                         req_data=req_data)

        for row in node.deleted_target_rows:
            # 키 데이터 생성
            key_data = {key: value for key, value in row.items() if key in node.key_columns}
            db_row = self._get_row_by_key(model=node.model, pk_data=key_data)

            LOGGER.debug(
                f'{type(self).__name__} _perform_delete - db_row type: {type(db_row)},'
                f' db_row type name: {type(db_row).__name__} ')

            if db_row is None:
                raise Exception('요청한 행을 찾을 수 없어 삭제 할 수 없습니다.')

            # Delete 실행
            node.model.objects.filter(**key_data).delete()

            # query 로그 삭제 -> 개선 필요

        # Post-Update 호출
        self._post_update(node=node,
                          update_type=UpdateType.Delete,
                          update_data=node.deleted_target_rows,
                          req_data=req_data)

    def _pre_update(self, node: BusinessNode, update_type: UpdateType, update_data: list, req_data) -> None:
        """변경된 데이터를 저장하기 전 호출되는 메서드입니다.
        필요시, 하위 클래스에서 재정의하여 사용합니다.
        Insert/Update의 경우, 저장할 데이터의 값을 변경하면 데이터베이스에 반영됩니다.

        :param node: 저장 작업을 진행하는 노드입니다.
        :param update_type: 저장 유형입니다.(Insert/Update/Delete)
        :param update_data: 저장할 데이터입니다.
        :param req_data: 저장 요청을 한 전체 데이터입니다.
        """
        pass

    def _post_update(self, node: BusinessNode, update_type: UpdateType, update_data: list, req_data) -> None:
        """변경된 데이터를 저장한 후 호출되는 메서드입니다.
        필요시, 하위 클래스에서 재정의하여 사용합니다.
        저장된 데이터의 값을 변경해도 데이터베이스에 반영되지 않습니다.

        :param node: 저장 작업을 진행하는 노드입니다.
        :param update_type: 저장 유형입니다.(Insert/Update/Delete)
        :param update_data: 저장된 데이터입니다.
        :param req_data: 저장 요청을 한 전체 데이터입니다.
        """
        pass

    def _exec_update(self, nodes: list, req_data, update_type: UpdateType) -> None:
        """노드의 관계에 따라 지정한 C/U/D에 해당하는 데이터를 저장합니다. 이 메서드는 Recursive하게 동작합니다.
        C/U/D순서: Delete -> Update -> Insert
        Delete: 가장 마지막 노드부터 Delete를 실행합니다.
        Insert/Update: 첫번째 노드부터 Insert/Update를 실행합니다.

        :param nodes: C/U/D를 실행할 노드
        :param req_data: 클라이언트에서 저장 요청한 데이터
        :param update_type: C/U/D 유형
        """
        # LOGGER.debug(f'{type(self).__name__} _exec_update - node name: {str(list(x.node_name for x in nodes))}')
        if update_type == UpdateType.Delete:
            for node in nodes:
                if len(node.nodes) > 0:
                    # 하위 노드 검색 및 실행
                    self._exec_update(nodes=node.nodes, req_data=req_data, update_type=update_type)
                if node.is_update:
                    self._perform_delete(node=node, req_data=req_data)

        if update_type == UpdateType.Update:
            for node in nodes:
                if node.is_update:
                    self._perform_update(node=node, req_data=req_data)
                if len(node.nodes) > 0:
                    # 하위 노드 검색 및 실행
                    self._exec_update(nodes=node.nodes, req_data=req_data, update_type=update_type)

        if update_type == UpdateType.Insert:
            for node in nodes:
                if node.is_update:
                    self._perform_insert(node=node, req_data=req_data)
                if len(node.nodes) > 0:
                    # 하위 노드 검색 및 실행
                    self._exec_update(nodes=node.nodes, req_data=req_data, update_type=update_type)

    def _set_update_result(self, req_data, node: BusinessNode, db_row) -> None:
        """DB에 저장된 db_row의 내용을 요청 데이터에 반영합니다. - delete / update

        :param req_data: 클라이언트에서 저장 요청한 데이터
        :param node: 저장행과 관련된 비즈니스 노드
        :param db_row: 저장된 DB 행(model를 통해 처리된 행)
        """
        # LOGGER.debug(f'{type(self).__name__} _set_update_result - node name: {node.node_name}')
        # datetime의 경우 rest_framework 설정의 포맷이 적용되지 않음->요청 데이터에 바로 적용했으므로.
        # db_row를 이용하여 요청 레코드를 찾는다.
        key_data = {attr_name: getattr(db_row, attr_name)
                    for attr_name, method in db_row.__class__.__dict__.items() if attr_name in node.key_columns}
        row = get_req_row(req_data_rows=req_data[node.table_name], key_data=key_data)
        if row is None:
            raise Exception('DB에 저장된 db_row의 내용을 요청 데이터에서 찾을 수 없습니다. - DataType 확인.')
        # db_row값을 요청 레코드에 반영한다.
        for col in node.update_columns:
            if type(getattr(db_row, col)) is datetime:
                row[col] = getattr(db_row, col).strftime('%Y-%m-%d %H:%M:%S')
            else:
                row[col] = getattr(db_row, col)

    def _set_row_stat_to_unchanged(self, nodes: list, req_data, update_type: UpdateType) -> None:
        """노드의 관계에 따라 클라이언트 요청 데이터의 행 상태를 unchanged로 변경합니다.
        이 메서드는 Recursive하게 동작합니다.
        Insert/Update된 행 -> row_stat를 unchanged로 변경합니다.
        Delete된 행 -> 요청 데이터에서 제거합니다.

        :param nodes: 행 상태를 변경할 노드 리스트
        :param req_data: 클라이언트 저장 요청 데이터
        :param update_type: 변경할 상태 값(검색 대상 상태 값)
        """
        if update_type == UpdateType.Delete:
            for node in nodes:
                if len(node.nodes) > 0:
                    # 하위 노드 검색 및 실행
                    self._set_row_stat_to_unchanged(nodes=node.nodes, req_data=req_data, update_type=update_type)
                if node.is_update:
                    # 삭제된 행을 요청 데이터에서 제거한다.
                    if node.deleted_rows is not None and len(node.deleted_rows) > 0:
                        for row in node.deleted_rows:
                            req_data[node.table_name].remove(row)
                        node.deleted_rows.clear()
                        node.deleted_target_rows.clear()
        if update_type == UpdateType.Update:
            for node in nodes:
                if node.is_update:
                    # 변경/추가된 행의 상태를 unchanged로 바꾼다.
                    if node.modified_rows is not None and len(node.modified_rows) > 0:
                        for row in node.modified_rows:
                            row['row_stat'] = 'unchanged'
                        node.modified_rows.clear()
                        node.modified_target_rows.clear()
                if len(node.nodes) > 0:
                    # 하위 노드 검색 및 실행
                    self._set_row_stat_to_unchanged(nodes=node.nodes, req_data=req_data, update_type=update_type)

        if update_type == UpdateType.Insert:
            for node in nodes:
                if node.is_update:
                    # 변경/추가된 행의 상태를 unchanged로 바꾼다.
                    if node.added_rows is not None and len(node.added_rows) > 0:
                        for row in node.added_rows:
                            row['row_stat'] = 'unchanged'
                        node.added_rows.clear()
                        node.added_target_rows.clear()
                if len(node.nodes) > 0:
                    # 하위 노드 검색 및 실행
                    self._set_row_stat_to_unchanged(nodes=node.nodes, req_data=req_data, update_type=update_type)

    def _set_row_stat(self, nodes: list, req_data):
        """노드의 관계에 따라 클라이언트 요청 데이터의 행 상태를 unchanged로 변경합니다.
        # 모든 변경된 데이터를 저장한 후 실행합니다.
        # row_stat 정리: Delete(제거) -> Update(modified->unchanged) -> Insert(added->unchanged)

        :param nodes: 행 상태를 변경할 노드 리스트
        :param req_data: 클라이언트 저장 요청 데이터
        """
        # LOGGER.debug(f'{type(self).__name__} _set_row_stat - node name: {str(list(x.node_name for x in nodes))}')
        self._set_row_stat_to_unchanged(nodes=self.nodes, req_data=req_data, update_type=UpdateType.Delete)
        self._set_row_stat_to_unchanged(nodes=self.nodes, req_data=req_data, update_type=UpdateType.Update)
        self._set_row_stat_to_unchanged(nodes=self.nodes, req_data=req_data, update_type=UpdateType.Insert)

    def _adjust_request_data(self, req_data) -> None:
        """저장 전에 요청 데이터를 사전 정리가 필요할 경우 이 메서드를 재정의합니다.
        _set_node_data() 메서드보다 먼저 실행됩니다.

        :param req_data: 저장 요청한 데이터
        """
        pass

    def _check_req_data(self, node: BusinessNode, req_data) -> dict:
        """요청 데이터를 저장하기 위해 node.update_columns 항목을 모두 갖고 있는지 검사합니다.

        :param node: 비즈니스 클래스에 정의된 노드
        :param req_data: 저장 요청한 데이터
        """
        # 저장할 데이터가 없거나, 저장하지 않는 노드이면 pass
        if node.table_name not in req_data or not node.is_update:
            return {'result': True, 'message': ''}

        # 저장할 데이터가 있는지 확인
        req_rows = req_data[node.table_name]
        if req_rows is None or len(req_rows) == 0:
            return {'result': True, 'message': ''}

        # 저장할 데이터가 있는지 확인
        target_rows = list(filter(lambda x: x['row_stat'] in ('added', 'modified', 'deleted'), req_rows))
        if target_rows is None or len(target_rows) == 0:
            return {'result': True, 'message': ''}

        # 노드에 업데이트 칼럼이 요청 데이터에 있는지 확인
        for row in target_rows:
            # 키 칼럼 체크
            key_result = list(key for key in node.key_columns if key not in row)
            if key_result is not None and len(key_result) > 0:
                o_result = str.join(', ', key_result)
                return {'result': False,
                        'message': f'''저장할 데이터({node.node_name}({node.table_name}), 키 칼럼-{o_result})를 모두 전송하지 않았습니다.'''}

            # 모든 필드 체크
            if node.check_update_columns:
                update_columns = node.update_columns.copy()
                # audit 칼럼은 제외
                update_columns = set(update_columns) -\
                                 {'first_rg_yms', 'first_rg_idf', 'last_update_yms', 'last_update_idf'}

                col_result = list(key for key in update_columns if key not in row)
                if col_result is not None and len(col_result) > 0:
                    o_result = str.join(', ', col_result)
                    return {'result': False,
                            'message': f'''저장할 데이터({node.node_name}({node.table_name}), 칼럼-{o_result})를 모두 전송하지 않았습니다.'''}

        return {'result': True, 'message': ''}

    def _set_node_data(self, nodes: list, req_data) -> None:
        """저장 요청 데이터의 상태에 따라 각 노드의 added, modified, deleted 속성에 설정합니다.

        :param nodes: 비즈니스 클래스에 정의된 노드
        :param req_data: 저장 요청한 데이터
        """
        for node in nodes:
            # 현재 노드의 저장할 데이터 확인
            check_result = self._check_req_data(node=node, req_data=req_data)
            if not check_result['result']:
                raise Exception(check_result['message'])

            # 현재 노드의 저장할 데이터 설정
            node.set_req_data(req_data)

            # 하위 노드도 실행
            self._set_node_data(node.nodes, req_data)

    def _exec_save(self, request) -> Response:
        """전송받은 데이터를 모두 저장합니다.
        노드의 관계와 데이터의 행 상태에 따라 실행합니다.

        가급적 이 메서드는 재정의하지 마십시오.
        """
        LOGGER.debug(f'{type(self).__name__} _exec_save - path: {request.path}')

        # 반환할 데이터
        return_data = {'success': True, 'code': 1, 'message': 'OK', 'data': None}

        try:
            request_data = request.data

            with transaction.atomic():
                # >> Begin transaction
                # Before Update -> 추후 처리(직접 구현 또는, django.signal 사용 검토)

                # 저장 전 요청 데이터 사전 정리 -> 필요 시 단위화면에서 재정의하여 사용
                self._adjust_request_data(req_data=request_data)
                # 각 노드별로 저장할 데이터 설정
                self._set_node_data(nodes=self.nodes, req_data=request_data)

                # 저장 실행: Delete -> Update -> Insert
                self._exec_update(nodes=self.nodes, req_data=request_data, update_type=UpdateType.Delete)
                self._exec_update(nodes=self.nodes, req_data=request_data, update_type=UpdateType.Update)
                self._exec_update(nodes=self.nodes, req_data=request_data, update_type=UpdateType.Insert)

                # After Update -> 추후 처리(직접 구현 또는, django.signal 사용 검토)

                # row 상태를 확정하여 반환한다.
                self._set_row_stat(self.nodes, req_data=request_data)

                return_data['data'] = request_data
                # >> End transaction

            return Response(return_data, status.HTTP_200_OK)
        except Exception as ex:
            LOGGER.exception(ex)
            LOGGER.exception(traceback.format_exc())
            return_data['success'] = False
            return_data['code'] = -1
            return_data['message'] = '예외 발생'
            # TODO: return_data['data'] = traceback.format_exc()
            return_data['data'] = str(ex)
            return Response(return_data, status.HTTP_400_BAD_REQUEST)

    # endregion

    # region Transaction 처리가 필요한 action 처리

    def _exec_action(self, request, func, **kwargs) -> Response:
        """트랜잭션 관리가 필요한 처리를 실행합니다.
        실행할 함수와 함수에 전달할 아규먼트를 지정하면 해당 함수를 트랜잭션 내에서 호출합니다.
        지정한 아규먼트 외에 req_data를 kwargs에 추가로 담아 호출합니다.

        가급적 이 메서드는 재정의하지 마십시오.

        :param request: F/E Request 객체
        :param func: 호출할 함수
        :param kwargs: 호출할 함수에 전달할 아규먼트(request 객체와 함께 전달합니다.)
        """
        LOGGER.debug(f'{type(self).__name__} _exec_action - path: {request.path}')

        # 반환할 데이터
        return_data = {'success': True, 'code': 1, 'message': 'OK', 'data': None}

        try:
            # 요청한 함수에 파라미터 추가(req_data)
            kwargs['req_data'] = request.data

            with transaction.atomic():
                # >> Begin transaction
                # 요청한 함수 실행
                result = func(**kwargs)
                # 실행 결과 설정
                return_data['data'] = result
                # >> End transaction

            return Response(return_data, status.HTTP_200_OK)
        except Exception as ex:
            LOGGER.exception(ex)
            return_data['success'] = False
            return_data['code'] = -1
            return_data['message'] = '예외 발생'
            # TODO: return_data['data'] = traceback.format_exc()
            return_data['data'] = str(ex)
            return Response(return_data, status.HTTP_400_BAD_REQUEST)

    # endregion

    # region Excel Export 메서드

    def _exec_export(self, request, func, **kwargs) -> HttpResponse:
        """생성한 엑셀 파일을 파일 다운로드로 Reponse합니다.

        func 함수는 {file_name, excel_file}을 반환해야 합니다.
        """
        LOGGER.debug(f'{type(self).__name__} _exec_download - path: {request.path}')

        # 반환할 데이터 -> 오류발생시에만 사용
        return_data = {'success': True, 'code': 1, 'message': 'OK', 'data': None}

        try:
            # 요청한 함수에 파라미터 추가(req_data)
            kwargs['req_data'] = request.data

            with transaction.atomic():
                # >> Begin transaction
                # 요청한 함수 실행
                export_result = func(**kwargs)
                # >> End transaction

            if export_result is None or export_result['excel_file'] is None:
                return_data['code'] = 0
                return_data['message'] = '내려받을 내용이 없습니다.'
                return Response(return_data, status.HTTP_200_OK)

            file_name = export_result['file_name']
            excel_file = export_result['excel_file']

            # important step, rewind the buffer or when it is read() you 'll get nothing
            excel_file.seek(0)

            # response 설정, mime 설정
            response = HttpResponse(excel_file.read(),
                                    content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
            # 다운로드 파일명 설정
            # file_name = urllib.parse.quote(kwargs['file_name'].encode('utf-8'))
            # response['Content-Disposition'] = 'attachment;filename*=UTF-8\'\'%s' % file_name
            response['Content-Disposition'] = f'attachment; filename={file_name}'

            return response
        except Exception as ex:
            LOGGER.exception(ex)
            return_data['success'] = False
            return_data['code'] = -1
            return_data['message'] = '예외 발생'
            # TODO: return_data['data'] = traceback.format_exc()
            return_data['data'] = str(ex)
            return Response(return_data, status.HTTP_400_BAD_REQUEST)

    # endregion


# Model 기반 API View
class BaseModelApiView(BaseApiView, metaclass=ABCMeta):
    """Model을 기반으로한 API View 베이스 클래스
    - 데이터 조회시 Model을 기반으로 조회하기 위한 베이스 클래스입니다.
    - 이 클래스를 상속한 하위 클래스에서는 self.defin_nodes() 메서드를 재정의하여 노드를 설정합니다.
    """

    # region 조회

    def _create_filter(self, node: BusinessNode, parameter_list=None, request_data=None, include_all=False):
        """Request body에 담긴 내용을 조회 파라미터로 변환합니다.
        이 메서드는 주어진 파라미터를 Q 형식으로 생성하고, AND 조건으로 적용합니다.
        더 복잡한 조건식을 적용하려면 이 메서드를 재정의해야 합니다.

        filter_data는 dict 형식과 Q 형식으로 만들 수 있습니다.

        :param parameter_list: 조회 조건을 설정할 파라미터명 리스트입니다.
        이 값이 있으면, 해당 파라미터의 값을 request_data에서 찾아 설정하고, request_data에 없으면 설정하지 않습니다.
        request_data에 추가로 설정된 key는 무시됩니다.
        이 값을 생략하면 request_data에 있는 값으로만 파라미터를 설정합니다.
        :param request_data: 조회 조건을 설정할 칼럼명:값 사전입니다.
        :param include_all: 조회 조건 값이 '%'일 경우, 파라미터를 설정할지 여부입니다. 값이 '%'이고,
         이 파라미터 값이 False이면 filter 설정에서 제외됩니다.
        """
        filter_data = Q()

        # self.kwargs 확인
        if len(self.kwargs) > 0:
            for key, value in self.kwargs.items():
                filter_data.add(Q(**{key: value}), Q.AND)

        # 요청 데이터 확인
        if len(request_data) == 0:
            return filter_data

        # 파라미터 명을 변수로 생성하여 Q 객체에 전달합니다. (string -> variable)
        if parameter_list:
            # 지정 파라미터명 리스트 있음 -> 요청 조건 중 지정 파라미터에 키가 있는 경우만 설정
            for key, value in request_data:
                if key in parameter_list:
                    filter_data.add(Q(**{key: value}), Q.AND)
        else:
            # 파라미터명 리스트 없음 -> 요청 조건을 그대로 설정
            for key, value in request_data:
                filter_data.add(Q(**{key: value}), Q.AND)

        # 코드 참고 - dict 를 이용하여 파라미터 설정
        # if parameter_list is not None and len(parameter_list) > 0:
        #     # 지정한 파라미터 목록이 있는 경우
        #     for key in parameter_list:
        #         if key in converted_request_data and (
        #                 converted_request_data[key] != '%' or (converted_request_data[key] == '%' and include_all)):
        #             filter_data[key] = converted_request_data[key]
        # else:
        #     # 지정한 파라미터 목록이 없는 경우
        #     for key in converted_request_data:
        #         if converted_request_data[key] != '%' or (converted_request_data[key] == '%' and include_all):
        #             filter_data[key] = converted_request_data[key]

        return filter_data

    def _set_query(self, node: BusinessNode, request_data: dict):
        """검색할 조건을 설정하여 해당 노드의 queryset 속성에 설정한다.
        복잡한 조건을 설정하거나 Join을 해야하는 경우, raw sql을 실행해야 하는 경우는 오버라이드하여 구현합니다.

        :param request_data: 클라이언트에서 요청한 데이터(검색 조건)
        :return: 기본 검색 조건을 설정한 queryset
        """
        LOGGER.debug(f'{type(self).__name__} _set_queryset - node name: {node.node_name}')
        filter_data = self._create_filter(node=node, parameter_list=None, request_data=request_data, include_all=False)
        # dict 타입 변수에 **을 붙이면 키워드 인수로 전달됨
        if filter_data is None:
            # TODO: 조건이 없을때 전체 데이터를 조회하게 할지 확정 요망
            node.queryset = node.model.objects.all().order_by(*node.sort_columns)
        else:
            # filter 타입에 따라 적용방식이 다름
            if type(filter_data) is Q:
                # Q이면 그대로 filter에 적용
                node.queryset = node.model.objects.filter(filter_data).order_by(*node.sort_columns)
            else:
                # Q가 아니면, kwargs로 적용
                node.queryset = node.model.objects.filter(**filter_data).order_by(*node.sort_columns)

    def _get_list(self, node):
        """node에 설정된 queryset을 이용하여 데이터 조회하고, 결과를 반환합니다.

        :param node: 조회를 실행하고자 하는 노드
        :return: 조회 결과(행 리스트)
        """
        LOGGER.debug(f'''{type(self).__name__} _get_list - node name: {node.node_name}
query: {node.queryset.query}''')

        # 조회 - using serializer
        if node.serializer is not None:
            serialized = node.serializer(node.queryset, many=True)
            serialized_data = serialized.data
        else:
            # 조회 - without serializer
            if len(node.select_columns) > 0:
                serialized_data = node.queryset.values(*node.select_columns)
            else:
                serialized_data = node.queryset.values()

        if len(serialized_data) > 0:
            # 조회한 데이터에 row 기본 상태값('unchanged')을 설정한다.
            for row in serialized_data:
                row['row_stat'] = 'unchanged'

        return serialized_data

    # endregion

    class Meta:
        abstract = True


# SQL 기반 API View
class BaseSqlApiView(BaseApiView, metaclass=ABCMeta):
    """SQL을 기반으로한 API View 베이스 클래스
    - 데이터 조회시 SQL을 기반으로 조회하기 위한 베이스 클래스입니다.
    - 이 클래스를 상속한 하위 클래스에서는 self.defin_nodes() 메서드를 재정의하여 노드를 설정합니다.
    """

    def __init__(self):
        # SQL 기반 조회를 위해, SQL 파일을 검색하고 파일을 읽을 Helper 입니다.
        # 하위 클래스의 define_nodes() 메서드에서 반드시 SqlFileHelper 객체를 등록해야 합니다.
        self._sql_helper: SqlFileHelper = None

        super().__init__()

    # region 조회

    def _create_filter(self, node: BusinessNode, parameter_list=None, request_data=None, include_all=False):
        """Request body에 담긴 내용을 조회 파라미터로 변환합니다.
        이 메서드는 dict 형식을 이용합니다.
        SQL을 이용하여 조회하므로 쿼리에 있는 파라미터를 모두 설정해야 합니다.
        더 복잡한 조건식을 적용하려면 이 메서드를 재정의해야 합니다.

        - 파라미터명 변환 - system_code -> p_system_code

        :param parameter_list: 조회 조건을 설정할 파라미터명 리스트입니다.
        이 값이 있으면, 해당 파라미터의 값을 request_data에서 찾아 설정하고, request_data에 없으면 설정하지 않습니다.
        request_data에 추가로 설정된 key는 무시됩니다.
        :param request_data: 조회 조건을 설정할 칼럼명:값 사전입니다.
        :param include_all: n/a
        """
        filter_data = {}

        # self.kwargs 확인, scheduler에 의해 호출될 경우 kwargs 없을 수 있음.
        if hasattr(self, 'kwargs') and len(self.kwargs) > 0:
            filter_data = dict((key, value) for key, value in self.kwargs.items())

        # 요청 데이터 확인
        if len(request_data) == 0:
            return filter_data

        if parameter_list:
            # 지정 파라미터명 리스트 있음 -> 요청 조건 중 지정 파라미터에 키가 있는 경우만 설정
            filter_data.update(dict((key, value) for key, value in request_data if key in parameter_list))
        else:
            # 파라미터명 리스트 없음 -> 요청 조건을 그대로 설정
            filter_data.update(request_data)

        return filter_data

    def _get_query(self, node: BusinessNode, request_data: dict):
        """해당 node에서 실행할 쿼리 설정
        - Sql 기반 View에서만 사용합니다.
        - 노드 정보에 설정된 SQL파일 정보로 쿼리 파일을 읽습니다.
        - 해당 노드가 실행할 쿼리를 바꾸려먼 이 함수를 재정의합니다.
        """
        sql_query = self._sql_helper.get_query(node.sql_filename)

        return sql_query

    def _set_query(self, node: BusinessNode, request_data: dict):
        """노드 설정에 명시된 조회 쿼리를 찾아서 설정합니다.

        :param request_data: 클라이언트에서 요청한 데이터(검색 조건)
        :return: 기본 검색 조건을 설정한 queryset
        """
        node.sql_query = self._get_query(node=node, request_data=request_data)
        node.sql_parameters = self._create_filter(node=node, request_data=request_data, include_all=True)

        # 파라미터 정규식 검색 패턴 - 예: %(p_파라미터명)
        pattern_string = "\\(p_[a-zA-Z0-9_]+\\)"
        regex = re.compile(pattern_string)
        found = set(regex.findall(node.sql_query))

        if len(found) > 0 and (node.sql_parameters is None or len(node.sql_parameters.items()) == 0):
            # sql 파라미터 설정 필요
            raise Exception('조회에 필요한 파라미터가 설정되지 않았습니다.')

        # sql 파라미터에서 괄호를 제거하여 요청 파라미터와 비교
        if not check_request_parameter(sql_param=[re.sub("[()]", "", substring) for substring in found],
                                       req_param=list(k for k, v in node.sql_parameters.items())):
            # sql 파라미터 설정 불충분
            raise Exception('조회에 필요한 파라미터를 모두 설정하지 않았습니다.')

    def _get_list(self, node: BusinessNode):
        """node에 설정된 query를 이용하여 데이터 조회하고, 결과를 반환합니다.

        :param node: 조회를 실행하고자 하는 노드
        :return: 조회 결과(행 리스트)
        """
        LOGGER.info(f'''{type(self).__name__} _get_list - node name: {node.node_name}
query: {node.sql_query}\n
query parameters: {node.sql_parameters}''')

        # 조회 query 실행
        serialized_data = db_helper.get_data(query=node.sql_query,
                                             parameters=node.sql_parameters,
                                             add_row_stat=True)

        return serialized_data

    # endregion

    class Meta:
        abstract = True
