# 기본 비밀번호 -> 신규 사용자 생성시 설정
DEFAULT_PASSWORD = '1'
