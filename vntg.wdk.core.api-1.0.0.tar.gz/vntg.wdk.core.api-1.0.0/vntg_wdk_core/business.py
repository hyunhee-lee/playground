from vntg_wdk_core.helper.data_helper import get_stat_rows, get_req_row


class BusinessNode:
    """조회/저장을 위한 노드 클래스
    조회/저장에 필요한 정보를 노드의 각 속성에 등록하여 View 클래스에서 사용합니다.
    """

    def __init__(self, **kwargs):
        self.node_name = ''
        """node 명은 api endpoint 명과 같아야 함(대소문자 주의)"""

        self.model = None
        """Model 기반 조회/저장, SQL 기반 저장을 위햔 Model"""

        self.queryset = None
        """Model 기반 조회를 위햔 QuerySet"""

        self.serializer = None
        """Model 기반 조회를 위햔 Serializer"""

        self.sql_filename = ''
        """SQL 기반 조회를 위한 Query 이름(SQL 파일명, .sql확장자 제외)"""

        self.sql_query = ''
        """SQL 기반 조회를 위한 Query(조회 실행시 자동 설정됩니다.)"""

        self.sql_parameters = {}
        """SQL 기반 조회를 위한 Query 파라미터 설정 -> 추후 사용"""

        self.table_name = ''
        """저장을 위한 DB 테이블명"""

        self.key_columns = []
        """저장을 위한 키 칼럼 리스트"""

        self.select_columns = []
        """조회할 칼럼 리스트(모델 사용시만 적용되며, 생략하면 모든 컬럼을 조회합니다.)"""

        self.sort_columns = []
        """정렬할 칼럼 리스트(모델 사용시만 적용되며, 생략하면 정렬되지 않습니다.)"""

        self.update_columns = []
        """저장할 칼럼 리스트(생략하면 해당 노드는 저장을 실행하지 않습니다.)"""

        self.check_update_columns = True
        """저장할 칼럼 체크 여부(기본값 True, 요청 데이터에 저장할 칼럼이 모두 있는지 체크합니다.
         False이면, 키 칼럼만 체크합니다.)"""

        self.nodes = []
        """노드 계층을 갖기 위한 노드 리스트"""

        self.req_rows = []
        """요청 데이터"""

        self.added_rows = []
        """요청 데이터 중 insert 대상 레코드"""

        self.modified_rows = []
        """요청 데이터 중 update 대상 레코드"""

        self.deleted_rows = []
        """요청 데이터 중 delete 대상 레코드"""

        self.added_target_rows = []
        """insert 대상 레코드 사본"""

        self.modified_target_rows = []
        """update 대상 레코드 사본"""

        self.deleted_target_rows = []
        """delete 대상 레코드 사본"""

        if len(kwargs) > 0:
            for key, value in kwargs.items():
                self.__setattr__(key, value)

    @property
    def is_update(self):
        """이 노드가 저장해야하는 노드인지 여부를 나타냅니다.
        update_columns 리스트에 값이 있으면 True, 없으면 False를 반환합니다.
        """
        if self.update_columns:
            return True
        else:
            return False

    def set_req_data(self, req_data):
        """요청 데이터를 Insert/Update/Delete 대상 행으로 구별하여 각 속성에 할당합니다.

        :param req_data: 저장 요청 데이터
        """
        # 노드에서 정의한 테이블이 저장 요청 데이터에 없으면 리턴
        if self.table_name not in req_data:
            return

        self.req_rows = req_data[self.table_name]
        self.added_rows = get_stat_rows(req_data=req_data, table_name=self.table_name, row_stat='added')
        self.modified_rows = get_stat_rows(req_data=req_data, table_name=self.table_name, row_stat='modified')
        self.deleted_rows = get_stat_rows(req_data=req_data, table_name=self.table_name, row_stat='deleted')
        
        # 저장할 칼럼으로 구성된 target_rows 생성
        self.added_target_rows = []
        for row in self.added_rows:
            # Insert 할 칼럼만 저장하기 위해 추출
            self.added_target_rows.append({key: value for key, value in row.items() if key in self.update_columns})
            # old 키 칼럼/값 추가(added 데이터의 경우 $old_칼럼 생성)
            # self.added_target_rows.append({'$old_' + key: value
            #                                for key, value in row.items() if key in self.key_columns})
        self.modified_target_rows = []
        for row in self.modified_rows:
            # Update 할 칼럼만 저장하기 위해 추출
            self.modified_target_rows.append({key: value for key, value in row.items() if key in self.update_columns})
        self.deleted_target_rows = []
        for row in self.deleted_rows:
            # Delete 할 칼럼만 저장하기 위해 추출(key 값만 있으면 되지만....)
            self.deleted_target_rows.append({key: value for key, value in row.items() if key in self.update_columns})

    def change_key_values(self, target_row: dict, new_key_data: dict) -> None:
        """이 노드의 Insert 할 레코드 중 지정한 레코드의 key 값을 변경합니다.
        이 함수를 통해 target_row 키 값을 변경해야 하며, 단위화면 business view 에서 호출해야 합니다.

        또한, 요청 데이터와 하위 노드의 key 값도 찾아서 변경합니다.
        node 의 키 칼럼 수와 파라미터의 키 값의 수는 같아야 합니다.

        :param target_row: 현재 노드의 저장(insert)할 레코드(사본)
        :param new_key_data: 변경하고자 하는 키값 사전
        """
        # key 칼럼/값 검사
        if len(self.key_columns) != len(new_key_data):
            raise Exception('변경할 키 값이 키 칼럼 수와 일치하지 않습니다!')

        # 변경전 키 값
        old_key_data = {key: value for key, value in target_row.items() if key in self.key_columns}

        # 저장할 데이터에 해당 키가 요청 데이터에 이미 존재하는지 검사
        # 새로 생성한 키값이 자신과 같아 요청 데이터에 있을 수 있음. 변경전 키로 자신을 제외하고 검색.
        other_rows = [row for row in self.req_rows
                      if all(row[target_key] != target_value
                             for target_key, target_value in old_key_data.items())]
        check_row = get_req_row(req_data_rows=other_rows, key_data=new_key_data)
        if check_row is not None:
            raise Exception('변경할 키 값이 이미 저장 요청한 데이터에 존재하여 저장할 수 없습니다.')

        # 요청 데이터 검색
        req_row = get_req_row(req_data_rows=self.added_rows, key_data=old_key_data)

        # 현재 레코드의 key 값 변경
        for key in self.key_columns:
            target_row[key] = new_key_data[key]
            req_row[key] = new_key_data[key]

        # 자식 노드의 key 값 변경
        change_child_node_key_values(self.nodes, self.key_columns, new_key_data, old_key_data)


#
# BusinessNode 클래스가 아닌 business.py 패키지에 있는 static 함수
#
def change_child_node_key_values(child_nodes: list, target_key_columns: list, target_key_data: dict,
                                 parent_old_key_data: dict) -> None:
    """하위 노드의 저장할 레코드(사본)에서 지장한 칼럼의 key

    :param child_nodes: 하위 노드 리스트
    :param target_key_columns: 키 값을 변경할 키 칼럼 목록
    :param target_key_data: 변경하고자 하는 키값 사전
    :param parent_old_key_data: 부모의 변경전 키 값
    """
    for node in child_nodes:
        if node.is_update and len(node.added_target_rows) > 0:
            # 모든 추가된 행에서 부모의 변경전 키 값의 영향을 받아야 하는 자식 행 추출
            target_rows = [row for row in node.added_target_rows
                           if all(row[target_key] == target_value
                                  for target_key, target_value in parent_old_key_data.items())]

            for change_target_row in target_rows:
                # 변경전 키 값
                old_key_data = {key: value for key, value in change_target_row.items() if key in node.key_columns}
                # 요청 데이터 검색
                req_row = get_req_row(req_data_rows=node.added_rows, key_data=old_key_data)
                # node의 전체 키값이 아닌, 지정한 키 값만 변경
                for key in target_key_columns:
                    change_target_row[key] = target_key_data[key]
                    req_row[key] = target_key_data[key]

                # 하위 노드 탐색
                change_child_node_key_values(child_nodes=node.nodes,
                                             target_key_columns=node.key_columns,
                                             target_key_data=old_key_data,
                                             parent_old_key_data=old_key_data)
