import logging

from rest_framework.serializers import ModelSerializer
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer

LOGGER = logging.getLogger(__name__)


# JWT Payload 를 커스터마이징하기 위한 Serializer
class MyTokenObtainPairSerializer(TokenObtainPairSerializer):
    """JWT Payload 를 커스터마이징하기 위한 Serializer"""

    @classmethod
    def get_token(cls, user):
        # 오버라이드
        token = super(MyTokenObtainPairSerializer, cls).get_token(user)

        LOGGER.debug(f'Login - {user.user_name}')
        # Add Custom claims
        token['user_name'] = user.user_name
        token['business_place'] = 'P'
        token['dept_name'] = 'F/W팀'
        token['role'] = 'user'
        return token

    def validate(self, attrs):
        # 오버라이드
        # data = super().validate(attrs)
        #
        # refresh = self.get_token(self.user)
        #
        # data['refresh'] = str(refresh)
        # data['access'] = str(refresh.access_token)
        #
        # if api_settings.UPDATE_LAST_LOGIN:
        #     update_last_login(None, self.user)
        #
        # return data
        data = super().validate(attrs)
        refresh = self.get_token(self.user)

        return_data = {
            'success': True,
            'code': 1,
            'message': 'OK',
            # 'data': {'refresh': str(refresh),
            #          'access': str(refresh.access_token)}
            'data': data
        }
        return return_data


# 기본 모델 Serializer
class BaseModelSerializer(ModelSerializer):
    """추후 Serializer의 공통 기능을 반영하기 위한 베이스 클래스
    """

    class Meta:
        # 추상 클래스 설정
        abstract = True
        fields = '__all__'
