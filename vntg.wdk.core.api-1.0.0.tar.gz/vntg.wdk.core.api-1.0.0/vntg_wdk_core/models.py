from datetime import datetime

from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin
from django.db import models
from django.db.models import QuerySet
from django.db.models.manager import BaseManager

from vntg_wdk_core.helper.request_helper import get_current_user


# Djangoo의 사용자 관리를 위한 빌트인 메서드 커스터마이징
# User 모델에서 사용해야 하므로, User 모델보다 먼저 작성
class CustomUserManager(BaseUserManager):
    def create_user(self, user_id, user_name, email, password=None):
        if not user_id:
            raise ValueError('Users must have an user id.')

        user = self.model()

        user.user_id = user_id
        user.user_name = user_name
        user.email = email
        user.use_yn = 'Y'
        user.user_level = 5
        user.system_type = 'S01'
        user.first_rg_yms = datetime.now()
        user.first_rg_idf = 'system'
        user.last_update_yms = datetime.now()
        user.last_update_idf = 'system'

        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_staffuser(self, user_id, user_name, email, password):
        user = self.create_user(user_id, user_name=user_name, email=email, password=password)

        user.user_level = 1
        user.save(using=self._db)
        return user

    def create_superuser(self, user_id, user_name, email, password):
        user = self.create_user(user_id, user_name=user_name, email=email, password=password)

        user.user_level = 0
        user.save(using=self._db)
        return user


# User 모델 커스터마이징
class User(AbstractBaseUser, PermissionsMixin):
    user_id = models.CharField(primary_key=True, max_length=20)
    user_name = models.CharField(max_length=50)
    # User 생성시 password 필드를 찾아서 alias 사용
    password = models.CharField(max_length=100, db_column='pwd')
    user_level = models.CharField(max_length=20, blank=True, null=True)
    use_yn = models.CharField(max_length=1, blank=True, null=True)
    emp_no = models.CharField(max_length=20, blank=True, null=True)
    tel_no = models.CharField(max_length=20, blank=True, null=True)
    email = models.CharField(max_length=100, blank=True, null=True)
    remark = models.CharField(max_length=500, blank=True, null=True)
    system_type = models.CharField(max_length=500, blank=True, null=True)
    first_rg_yms = models.DateTimeField(blank=True, null=True)
    first_rg_idf = models.CharField(max_length=20, blank=True, null=True)
    last_update_yms = models.DateTimeField(blank=True, null=True)
    last_update_idf = models.CharField(max_length=20, blank=True, null=True)

    # 사용자 생성을 위한 관리자 지정
    objects = CustomUserManager()

    # Django가 사용자를 인식하는 필드
    USERNAME_FIELD = 'user_id'
    REQUIRED_FIELDS = ['user_name', 'email']

    class Meta:
        # managed = False이면 migration 스크립트가 만들어져도 db에 반영 안함
        managed = False
        # 실제 DB 테이블 명
        db_table = 'cm_user'
        # settings.AUTH_USER_MODEL이라는 속성에 의해서 무엇인가가 바뀔 수 있다는 것을 의미
        swappable = 'AUTH_USER_MODEL'

    def __str__(self):
        return self.user_name

    def get_full_name(self):
        return self.user_name

    def get_short_name(self):
        pass

    @property
    def is_superuser(self):
        if self.user_level == 0:
            return True
        else:
            return False

    @is_superuser.setter
    def is_superuser(self, value):
        if value:
            self.user_level = 0
        else:
            self.user_level = 5

    @property
    def is_staff(self):
        if self.user_level == 0 or self.user_level == 1:
            return True
        else:
            return False

    @is_staff.setter
    def is_staff(self, value):
        if value:
            if self.user_level >= 5:
                self.user_level = 1
        else:
            if self.user_level >= 1:
                self.user_level = 5

    @property
    def last_login(self):
        return self.last_update_yms

    @property
    def date_joined(self):
        return self.first_rg_yms

    def has_perm(self, perm, obj=None):
        return self.is_superuser

    def has_module_perms(self, app_label):
        return self.is_superuser


class NullCharField(models.CharField):
    """Null 허용 칼럼에 빈 문자열이 아닌 null 저장되도록 변환하는 커스텀 필드입니다.
    이 필드를 사용하면, 빈 문자열이 저장될 경우 null로 바꿔 저장합니다.
    Null 허용 칼럼에만 사용합니다.
    """
    def get_prep_value(self, value):
        if value == '':
            return None
        return value


class NullTextField(models.TextField):
    """Null 허용 칼럼에 빈 문자열이 아닌 null 저장되도록 변환하는 커스텀 필드입니다.
    이 필드를 사용하면, 빈 문자열이 저장될 경우 null로 바꿔 저장합니다.
    Null 허용 칼럼에만 사용합니다.
    """

    def get_prep_value(self, value):
        if value == '':
            return None
        return value


class BaseModelQuerySet(QuerySet):
    def create(self, **kwargs):
        # 현재 사용자
        user = get_current_user()

        # 저장 전 생성/수정 정보 설정위해 override
        kwargs['first_rg_yms'] = datetime.now()
        kwargs['first_rg_idf'] = user.user_id
        kwargs['last_update_yms'] = datetime.now()
        kwargs['last_update_idf'] = user.user_id

        # Now call the super method which does the actual creation
        return super().create(**kwargs)

    def update(self, **kwargs):
        # 현재 사용자
        user = get_current_user()

        # 저장 전 수정 정보 설정위해 override
        kwargs['last_update_yms'] = datetime.now()
        kwargs['last_update_idf'] = user.user_id

        return super().update(**kwargs)

    def bulk_create(self, objs, batch_size=None, ignore_conflicts=False):
        # 현재 사용자
        user = get_current_user()

        # 저장 전 생성/수정 정보 설정
        for row in list(objs):
            row.first_rg_yms = datetime.now()
            row.first_rg_idf = user.user_id
            row.last_update_yms = datetime.now()
            row.last_update_idf = user.user_id

        super().bulk_create(objs, batch_size, ignore_conflicts)

    def bulk_update(self, objs, fields, batch_size=None):
        super().bulk_update(objs, fields, batch_size)


class BaseModelManager(BaseManager.from_queryset(BaseModelQuerySet)):
    pass


# 테이블의 모델에서 사용할 베이스 클래스
class BaseTableModel(models.Model):
    """생성/수정 날짜와 사용자 칼럼을 사용하는 테이블의 모델에서 사용할 베이스 클래스
    """
    first_rg_yms = models.DateTimeField(blank=True, null=True, auto_now_add=True)
    first_rg_idf = models.CharField(max_length=20, blank=True, null=True)
    last_update_yms = models.DateTimeField(blank=True, null=True, auto_now=True)
    last_update_idf = models.CharField(max_length=20, blank=True, null=True)

    # Insert/Update 오버라이드하기 위해 Manager 설정
    objects = BaseModelManager()

    # 모델에서 Delete 오버라이드할 경우
    # def delete(self, *args, **kwargs):
    #     super().delete(*args, **kwargs)

    class Meta:
        # 추상 클래스 설정
        abstract = True
